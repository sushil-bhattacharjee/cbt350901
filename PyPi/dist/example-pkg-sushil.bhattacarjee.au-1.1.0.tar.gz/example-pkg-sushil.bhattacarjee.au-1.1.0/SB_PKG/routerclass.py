class Router:
    def __init__(self, hostname, ipadd, devtype):
        self.hostname = hostname
        self.ipadd = ipadd
        self.devtype = devtype
